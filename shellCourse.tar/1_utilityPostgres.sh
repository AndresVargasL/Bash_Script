#!/bin/bash
# Programa para realizar algunas operaciones utilitarios de postgres
echo "Hola, bienvenido al cusro de programacion bash"
