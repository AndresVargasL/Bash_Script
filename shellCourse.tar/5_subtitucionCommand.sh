#!/bin/bash
#Progrma para revisar como ejecutar comandos dentro de un programa y almacenar en una variable
#para su posterior utilizacion
#Autor: Sergio A. Vargas

ubicacionActual=`pwd`
infoeKernel=$(uname -sr)

echo "La ubicaci[on actual es la siguiente: $ubicacionActual"
echo "Informacion del Kernel $infoKernel"
